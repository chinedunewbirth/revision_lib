# revision_lib

**Automate Python library upgrades and check version compatibility.**

`revision_lib` is a PyPI-ready Python library that helps developers safely upgrade their Python dependencies by checking for outdated packages, verifying version compatibility before upgrading, and automating the upgrade process.

## Features

- **Version Checking** — Query installed package versions and compare with the latest on PyPI
- **Compatibility Analysis** — Detect dependency conflicts *before* upgrading
- **Environment Health Scan** — Find existing dependency conflicts in your environment
- **Safe Upgrades** — Upgrade packages only when compatibility is confirmed
- **Upgrade Planning** — Dry-run mode to preview what would happen
- **CLI & API** — Use from the command line or import into your own scripts

## Installation

```bash
pip install revision_lib
```

For development:

```bash
pip install revision_lib[dev]
```

## Quick Start

### Command Line

```bash
# Check a single package for updates
revision check requests

# Check all installed packages for updates
revision check --all

# Check if upgrading is safe (compatibility check)
revision compat requests
revision compat requests 2.31.0

# Scan your environment for existing dependency conflicts
revision env-check

# Preview upgrade plan (dry run)
revision plan requests flask

# Upgrade a package (with safety checks)
revision upgrade requests

# Upgrade all outdated packages
revision upgrade --all

# Force upgrade (skip compatibility checks)
revision upgrade requests --force

# Upgrade to a specific version
revision upgrade requests --version 2.31.0
```

### Python API

```python
from revision_lib import VersionChecker, CompatibilityChecker, Upgrader

# --- Check versions ---
checker = VersionChecker()

# Single package
info = checker.check_package("requests")
print(f"{info.name}: {info.installed_version} -> {info.latest_version}")
print(f"Outdated: {info.is_outdated}")

# All installed packages
packages = checker.get_installed_packages()

# Find all outdated packages
outdated = checker.find_outdated()
for pkg in outdated:
    print(f"{pkg.name}: {pkg.installed_version} -> {pkg.latest_version}")

# --- Check compatibility ---
compat = CompatibilityChecker()

# Check if upgrading requests to latest is safe
report = compat.check_upgrade_compatibility("requests")
print(f"Compatible: {report.is_compatible}")
for conflict in report.conflicts:
    print(f"  Conflict: {conflict.reason}")

# Check against a specific version
report = compat.check_upgrade_compatibility("requests", "2.31.0")

# Scan entire environment for conflicts
conflicts = compat.full_environment_check()

# --- Upgrade packages ---
upgrader = Upgrader()

# Plan upgrades (dry run)
plan = upgrader.plan_upgrades(["requests", "flask"])
for item in plan.upgrades:
    print(f"{item.package}: {item.status.value}")

# Execute upgrade with safety checks
result = upgrader.upgrade_package("requests")
print(f"Status: {result.status.value}")

# Upgrade all outdated packages
results = upgrader.upgrade_packages()
```

## Architecture

```
revision_lib/
├── __init__.py          # Public API exports
├── checker.py           # Version checking (installed vs PyPI)
├── compatibility.py     # Dependency conflict detection
├── upgrader.py          # Safe upgrade automation
└── cli.py               # Command-line interface
```

### Modules

| Module | Class | Purpose |
|--------|-------|---------|
| `checker` | `VersionChecker` | Query installed versions, fetch PyPI metadata, find outdated packages |
| `checker` | `PackageInfo` | Data class holding version information for a package |
| `compatibility` | `CompatibilityChecker` | Check reverse dependencies, validate version constraints, scan environment |
| `compatibility` | `CompatibilityReport` | Result of a compatibility check with conflicts and warnings |
| `compatibility` | `Conflict` | Data class describing a specific dependency conflict |
| `upgrader` | `Upgrader` | Plan and execute upgrades with pre-flight compatibility checks |
| `upgrader` | `UpgradeResult` | Result of an upgrade attempt |
| `upgrader` | `UpgradePlan` | Collection of planned upgrades with summary |

## How It Works

1. **Check** — `VersionChecker` queries `importlib.metadata` for installed versions and the PyPI JSON API for latest versions
2. **Analyze** — `CompatibilityChecker` inspects reverse dependencies (packages that depend on the target) and forward dependencies (packages the new version requires) to detect conflicts
3. **Upgrade** — `Upgrader` runs the compatibility check first, then invokes `pip install package==version` only if no conflicts are found (unless `--force` is used)

## Development

```bash
# Clone the repo
git clone https://github.com/chinedunewbirth/revision_lib.git
cd revision_lib

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Run tests with coverage
pytest --cov=revision_lib
```

## License

MIT License. See [LICENSE](LICENSE) for details.
